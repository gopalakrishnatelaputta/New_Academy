
import './App.css';
import DashBoardScreen from "./Components/DashBoardScreen.jsx"

function App() {
  return (
    
      <DashBoardScreen/>
        
      
    
  );
}

export default App;
