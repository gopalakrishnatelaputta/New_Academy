// MiddileLeftCorner.jsx
import { Box, Card, Grid, Typography } from '@mui/material';
import React from 'react';
import ReactApexChart from 'react-apexcharts';
import InterestBox from './CommonBoxMiddleCenter/InterestBox';

export default function MiddileLeftCorner() {
  const categories = ['Java', 'SQL', 'JScript', 'Python', 'ReactJs', 'C Lang'];
  const categoryColors = ['#0D6904', '#D0EF0A', '#1FA305', '#0759EA', '#F609F9', '#DF0808'];
  
  // Dynamically create the colors array based on the length of categories
  const colors = categories.map((category, index) => categoryColors[index % categoryColors.length]);
  
  const chartOptions = {
    series: [{
      data: [400, 470, 540, 320, 1200, 1380]
    }],
    chart: {
      type: 'bar',
      height: 350
    },
    plotOptions: {
      bar: {
        borderRadius: 4,
        horizontal: true,
        dataLabels: {
          enabled: false, // Disable data labels
        },
      }
    },
    colors: colors,
    xaxis: {
      categories: categories,
    }
  };
  
  
  return (
    <Card elevation={2} sx={{ ml: '5px', mr: '15px', height: '250px', borderRadius: '5px', mt: '5px',  color: 'var' }}>
      <Grid container>
        <Box sx={{ display: 'flex', flexDirection: 'row' }}>
          <Box sx={{ display: 'flex', flexDirection: 'column' }}>
            <Box sx={{ height: ['20px', '30px'], alignItems: 'center', mt: ['10px', '20px'] }}>
              <Typography fontSize={'17.5px'} ml={['10px', '15px']}>
                Topics you are interested in
              </Typography>
            </Box>

            <Box sx={{ display: 'flex', alignItems: 'end', mt: ['5px', '5px'], ml: '20px' }}>
              <ReactApexChart options={chartOptions} series={chartOptions.series} type="bar" height={200} />
            </Box>
          </Box>
          <Box sx={{ display: 'flex', flexDirection: 'row' }}>
            <Box sx={{ display: 'flex', flexDirection: 'column', m: '50px' }}>
              <InterestBox name="Java" percentage={26.67} />
              <InterestBox name="SQL" percentage={31.33} />
              <InterestBox name="JScript" percentage={36.00} />
            </Box>
            <Box sx={{ display: 'flex', flexDirection: 'column', m: '50px' }}>
              <InterestBox name="Python" percentage={21.33} />
              <InterestBox name="ReactJs" percentage={80.00} />
              <InterestBox name="C Lang" percentage={92.00} />
            </Box>
          </Box>
        </Box>
      </Grid>
    </Card>
  );
}
