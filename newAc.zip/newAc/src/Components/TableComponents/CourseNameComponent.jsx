import React from 'react';
// import MoreVertIcon from '@mui/icons-material/MoreVert';


const CourseNameComponent = () => {

   


    return (
        <div>
        
            
        </div>
    );
}

export default CourseNameComponent;
