import React from 'react';
import { Typography, Box, Card } from '@mui/material';
import LaptopIcon from '@mui/icons-material/Laptop';
import TipsAndUpdatesIcon from '@mui/icons-material/TipsAndUpdates';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import { TopLeftCornerCss } from './CssFiles/TopLeftCornerCss';

export default function TopLeftCorner() {
  return (
    <Box style={TopLeftCornerCss.topLeftCornerContainer}>
      <Box style={TopLeftCornerCss.greeting}>
        <Typography variant="h5">
          Welcome back, Felecia 👋🏻
        </Typography>
        <Typography variant="subtitle1" style={TopLeftCornerCss.subtitle}>
          Your progress this week is awesome. Let's keep it up and get a lot of points reward!
        </Typography>
      </Box>
      
      <Box style={TopLeftCornerCss.cardsContainer}>
        <Box style={TopLeftCornerCss.cardWrapper}>
          <Card style={TopLeftCornerCss.card}>
            <LaptopIcon style={TopLeftCornerCss.icon} />
          </Card>
          <Box style={TopLeftCornerCss.hoursSpent}>
            <Typography variant="subtitle1" color={'#544f5a'}>Hours Spent</Typography>
            <Typography variant="h6" style={TopLeftCornerCss.icon}>
              34h
            </Typography>
          </Box>
        </Box>

        <Box style={TopLeftCornerCss.cardWrapper}>
          <Card style={TopLeftCornerCss.card}>
            <TipsAndUpdatesIcon style={TopLeftCornerCss.icon} />
          </Card>
          <Box style={TopLeftCornerCss.result}>
            <Typography variant="subtitle1" color={'#544f5a'}>Test Results</Typography>
            <Typography variant="h6" style={TopLeftCornerCss.icon}>
              82%
            </Typography>
          </Box>
        </Box>

        <Box style={TopLeftCornerCss.cardWrapper}>
          <Card style={TopLeftCornerCss.card}>
            <TaskAltIcon style={TopLeftCornerCss.icon} />
          </Card>
          <Box style={TopLeftCornerCss.completed}>
            <Typography variant="subtitle1" color={'#544f5a'}>Course Completed</Typography>
            <Typography variant="h6" style={TopLeftCornerCss.icon}>
              23
            </Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
